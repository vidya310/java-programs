package CO4Q2.operations;

public interface calculate {
    void cal(int x, int y);
}
